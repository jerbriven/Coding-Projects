To run my code, you can execute aClientInsert.exe. You can also compile and run aClient.cpp. You will see some warnings, but it still
compiles correctly. This is just due my compiler version and the exception calls. I inserted an unsorted array of characters into the 
array bag. I then altered the insertion sort funciton so it utilizes the member functions to sort its items. I then print all of the
contents to show that the sorting was successful. Similar to problem 1, the time complexity is n^2 for insertion sort's worst and average
case. Its best case has a time complexity of n. I chose this algorithm because it is relatively simple and easy to implement with the
class. It is also a very common sorting algorithm.