To run my code you can either execute mainTest.exe, or compile and run main.cpp.
I created a circular linked list to represent the queue. It has three member functions:
enqueue, dequeue, and read. Enqueue appends an element to the end of the queue. Dequeue
removes an element from the front of the queue. Read is a function meant for test purposes.
It reads through the queue from beginning to end. It demonstrates that the enqueue and dequeue
functions are working.