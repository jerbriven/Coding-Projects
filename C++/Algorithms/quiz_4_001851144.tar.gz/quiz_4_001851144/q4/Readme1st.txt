To run my code, you can execute the mainTest.exe file. You can also compile
and run the main.cpp file. In order to accomplish this question, I used the 
code given. I added the functions that were not provided within BinaryNodeTree.
In my main file, I tested the various functions given in BinaryTreeInterface.h.
These are all implemented as public functions within my BinaryNodeTree class.
Each of these public functions use protected functions in order to accomplish each
of the intended functionalities.