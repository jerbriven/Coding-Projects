To run my code, you can execute queuePalinTest.exe. You can also
compile and run main.cpp. I altered quiz 2 question 3 for my
solution. I also reused the queue class created in question 1.
Since we are using queues instead of stacks, I merely had to 
reverse the way my function works. This is because the OurQueue
class reads and pops at the front, not the back.