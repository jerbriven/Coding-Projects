To run my code, execute radixTest.exe. You can also compile and
run radixMain.cpp. I altered my code from quiz 3 question 4 for 
this question. Instead of using an array, it uses the queue class
from question 1. I used an array of 10 elements as the input array
to be sorted using radix sort. I used the various member functions
of OurQueue in order to alter the functions. The final queue 
was sorted, but backwards. So the final output is displayed in
reverse.