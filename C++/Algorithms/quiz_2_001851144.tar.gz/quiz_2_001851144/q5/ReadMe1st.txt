To run the code for this question, you can execute doubledEnded.exe.
You can also compile the main.cpp file. I altered my doubly linked
list from quiz 1. I changed it to a singly linked list with a
tail so that it could be a double ended list. I altered the remove
last item in order to do it with just next nodes, a head, and a
tail. I made a set of tests that demonstrate removing, adding,
and reading the first and last items of the list.