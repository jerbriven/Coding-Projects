To run my code, you can run my palinTest.exe. If you want to
compile yourself, compile the palinMain.cpp file. I wrote a
recursive isPalindrome function. It has a base case of a string
that contains 1 or 0 items, or if its first and last character
do not match. This determines whether or not the string is a
palindrome. Each iteration of the function, the strings front
and back characters are removed. My test cases are a few known
palidromes, non palindromes, and some of the direct base cases.
These specific cases were strings with 2, 1, and 0 characters.