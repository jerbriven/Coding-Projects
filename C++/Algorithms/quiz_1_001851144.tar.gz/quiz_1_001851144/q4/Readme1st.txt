You can either run my bagTest.exe in command line, or compile
and run my main.cpp file using g++. It imports the text file
spellCheck.txt. It checks if the words within the sentence
"The dog walked to the store" are spelled correctly. I have
the correctly spelled words stored within the bag. I
purposely mispelled some of the words in order to see if the
code worked. If you run my code, you should see the same
result.