In order to run my code, you can run the test.exe in
command line. If you want to compile my test function first,
use g++ to compile getNumTest.cpp. This allows you to see
the clock time and flops of the array function for three
arrays.