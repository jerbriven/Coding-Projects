You can either run octal.exe in command line, or compile and
run testOctal.cpp with g++. I have 78 as the input number,
which outputs 116 in octal.