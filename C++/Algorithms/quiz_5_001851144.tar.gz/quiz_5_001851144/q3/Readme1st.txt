To run my code, execute dictTest.exe. You can also compile and run the main.cpp file. You will see some warnings about some of the
exception files, but this does not effect compilation. This is merely due to my c++ version having deprecated throws. I completed the
function definitions for ArrayDictionary and Entry classes. Once this was completed, I added a few simple items to the dictionary. The
items are names of people, and the keys are birthday months in integer form. This means the names are sorted based on birthday month
(1-12). I created a few test functions to implement each of the ArrayDictionary.h public member functions. You can see the various
outputs success when executing my code. My class mostly revolves around binary search, as this is how key values are found within 
the array. This is beneficial for adding new items, removing items, and checking items.