To run my code, you can execute treeTest.exe or compile and run
my main.cpp file. I reused a lot of my code from the previous
question. I also reused the binary search tree implementation
from the previous quiz. Treedictionary merely instantiates a
binary search tree. This time, the nodes each have a key and
item. This is what truly makes it a dictionary tree, not just
one value per node. I implemented a test in order to show the
compiler functionality. I added three different named floats,
doubles, and a integer. When I try to add another variable of
the same name as previous, my program prevents me from doing so.
I also output the contents at the end. As you can see, the 
keywords are sorted alphabetically using ascii.