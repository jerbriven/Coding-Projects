In order to test my code, execute the testPriority.exe file. You can also compile and run the main.cpp file. I added the necessary
functions to the ArrayMaxHeap.cpp file to make it functional. I used an array of strings in order to store priority for each. These
priority index values are then stored in the priority queue. As you can see, my highest priority item is on the top of the queue. This
is also the item that is removed. The most important task is the first one that is checked off. You may seem some warnings when trying
to compile, but this does not effect creating the executable.