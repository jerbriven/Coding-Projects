Since no coding was needed here, and the main test file already
exists, all of my answers are within the attached pdf. Please
look there to see my example and proof of the tree height.