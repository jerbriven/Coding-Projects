To run my code, execute mainTest.exe or compile and run main.cpp. I created a class
that has the member functions described in the question prompt. This creates the
recursive strategy desired here. In my main file, I test two different sets of
possible infix expressions. The boolean result of isValid is then outputted. This
shows that my class successfully identifies a valid infix expression.