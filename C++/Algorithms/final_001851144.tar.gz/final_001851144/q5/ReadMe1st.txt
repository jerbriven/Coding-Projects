In order to run my code, mainTest.exe can be executed. Main.cpp can also be
compiled and ran as an executable. In order to accomplish this question, I
reused my adjacency matrix class from the last quiz. I added two new methods that
uses dijkstra's algorithm to calculate shortest distance from 0 to 6. I output
the adjacency matrix that represents the graph given. I also output the shortest
path distance between 0 and 6. 