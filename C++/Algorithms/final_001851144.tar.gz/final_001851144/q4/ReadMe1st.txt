In order to test my code, you can execute mainTest.exe. Main.cpp can also be
compiled and ran. Since there was only a search by key function, I created a search
member function that can search by the 3 node values. Once this node is found,
its float, integer, and string values are changed to the new ones. As you can see
in my test, node 15 is replaced with the values I specify.