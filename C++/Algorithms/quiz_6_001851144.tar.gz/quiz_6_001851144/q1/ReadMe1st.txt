To run my code, you can execute mainTest.exe. If you wish to compile the main file,
compile and run main.cpp. I chose the adjacency matrix route, creating a class
that inherits the GraphInterface.h class. It creates a graph containing 10 nodes
by default, integers 0-9. In my main file, I added a few edges between these nodes.
I made a few cout statements in order to test the various functions of the 
AdjacencyMatrix.cpp.