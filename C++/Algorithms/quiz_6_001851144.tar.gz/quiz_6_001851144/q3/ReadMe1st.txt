To run my code, you can execute mainTest.exe or compile main.cpp. I reused my code from question 1 
in order to create the adjacency matrix. I created a new print function that prints the adjacency matrix
based on the graph given in the question. I did a breadth first search and depth first search starting from C.
As you can see, breadth first search finds 'i' first. Therefore, I would choose breadth first search. I also
assumed the graph given was undirected. This is due to the fact that it would be impossible to find 'i' from 
c based on the given directed graph. I also retested some of the similar functionalities from question 1.