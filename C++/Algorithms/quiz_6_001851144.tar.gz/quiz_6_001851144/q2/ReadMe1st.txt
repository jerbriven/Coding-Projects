To run my code, execute mainTest.exe. You can also compile and
run main.cpp. In order to make this functional, I simply created
the less than and printKey functions in my main file. Then,
these functions are passed in the constructor of my bTree
object. I then tested the various public functions of bTree.
For the B plus tree, my main files are main2.cpp and mainTest2.exe
I tested similar functionality to the previous part here.